# VioletCore Build Report

Date: 2026-07-26

## Base

- Upstream: https://github.com/PurpurMC/Purpur.git
- Branch: `ver/26.2`
- Commit used: `3c029ce0827f4c56667b6e17c0b7f6728747f40d`

## Build environment

- Java used for build: Temurin JDK 25.0.3
- Gradle wrapper: 9.4.1

## Build status

Successful:

```text
./gradlew applyAllPatches
./gradlew :purpur-api:compileJava :purpur-server:compileJava
./gradlew :purpur-server:createBundlerJar -x test
```

Output:

```text
/home/user/VioletCore-26.2.local-SNAPSHOT.jar
```

## Smoke test

Command:

```bash
java -Xmx768M -jar /home/user/VioletCore-26.2.local-SNAPSHOT.jar --nogui --initSettings --engine-plugins-dir engine-plugins
```

Result:

- VioletCore loaded the example Engine Plugin.
- Engine Plugin registered tick observer and entity tick controller.
- Server initialized settings and exited at EULA step as expected.
- A second short run with `eula=true` reached `Done (...)` and shut down cleanly.
- Logs saved at `/home/user/violetcore-init-test.log` and `/home/user/violetcore-run-test.log`.
