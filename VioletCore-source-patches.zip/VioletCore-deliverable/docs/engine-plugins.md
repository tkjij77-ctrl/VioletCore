# VioletCore Engine Plugins

Engine Plugins are early-loaded server plugins. They are separate from normal Bukkit/Paper plugins.

## Folder

Default folder:

```text
engine-plugins/
```

Alternative:

```bash
--engine-plugins-dir custom-folder
```

## Lifecycle

```text
1. org.bukkit.craftbukkit.Main parses startup options
2. VioletCore EnginePluginManager scans engine-plugins/
3. Metadata is validated
4. Conflicts are checked
5. Engine Plugin main class is loaded
6. EnginePlugin#onLoad(context) is called
7. Paper/Purpur bootstrap continues
8. Normal plugins load from plugins/
```

## Reload policy

Engine Plugins are restart-only. When any Engine Plugin is loaded, `/reload` is cancelled by default.

Override for debugging only:

```bash
-DVioletCore.AllowReloadWithEnginePlugins=true
```

## Safe hook API

Current MVP hooks:

```java
context.registerTickObserver(new TickObserver() {
    @Override
    public void onServerTickStart(int tick) {}

    @Override
    public void onServerTickEnd(int tick, double tickDurationMillis, long remainingNanos) {}
});

context.registerEntityTickController((entity, worldName, tick) -> {
    // return false to skip this entity tick
    return true;
});
```

## Not yet enabled

Restricted Mixin/bytecode transformation support is planned but not enabled in this MVP.
