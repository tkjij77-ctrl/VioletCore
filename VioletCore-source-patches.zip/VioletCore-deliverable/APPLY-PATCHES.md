# Applying VioletCore patches to official Purpur 26.2

1. Clone official Purpur 26.2:

```bash
git clone --branch ver/26.2 --single-branch https://github.com/PurpurMC/Purpur.git VioletCore
cd VioletCore
```

2. Copy the patch files from this bundle into the same relative locations inside the clone.

3. Apply and build:

```bash
./gradlew applyAllPatches
./gradlew :purpur-server:createBundlerJar -x test
```

4. Output jar:

```text
purpur-server/build/libs/purpur-bundler-26.2.local-SNAPSHOT.jar
```

This workspace already includes the prebuilt jar as `VioletCore-26.2.local-SNAPSHOT.jar`.
