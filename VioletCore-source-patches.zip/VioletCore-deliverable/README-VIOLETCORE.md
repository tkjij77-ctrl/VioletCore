# VioletCore 26.2

VioletCore is a Purpur 26.2 based server software prototype that keeps normal Bukkit/Paper/Purpur plugin compatibility and adds an early **Engine Plugin** layer.

## What was implemented

- Based on official `PurpurMC/Purpur` branch `ver/26.2`.
- Rebranded runnable server jar metadata to `VioletCore`.
- Added `engine-plugins/` loader before the Paper/Purpur server bootstrap.
- Added command-line options:
  - `--engine-plugins-dir <dir>` / `--core-plugins-dir <dir>`
  - `--disable-engine-plugins`
- Added strict Engine Plugin version checks:
  - `target-server: VioletCore`
  - `target-version: 26.2`
- Added conflict detection through `modifies:` and `conflicts:` metadata.
- Added restart-only policy: `/reload` is cancelled when Engine Plugins are loaded unless `-DVioletCore.AllowReloadWithEnginePlugins=true` is set.
- Added Engine Plugin crash-report details.
- Added safe tick observer hooks:
  - `TickObserver#onServerTickStart(int tick)`
  - `TickObserver#onServerTickEnd(int tick, double tickDurationMillis, long remainingNanos)`
- Added an Engine Plugin entity-ticking hook:
  - `EntityTickController#shouldTickEntity(Entity entity, String worldName, int tick)`
  - Returning `false` skips normal ticking for that entity for that tick.
- Built runnable jar: `VioletCore-26.2.local-SNAPSHOT.jar`.
- Built example Engine Plugin: `example-engine-plugin/ExampleTickObserver-1.0.0.jar`.

## Current important limitation

This MVP implements the Engine Plugin loader plus real server hooks, including tick observation and entity tick control. It does **not** yet apply Mixin bytecode transformations. Metadata can declare `mixin-configs`, but the loader logs that restricted Mixin support is planned and not enabled in this MVP.

## Running

```bash
java -Xmx2G -jar VioletCore-26.2.local-SNAPSHOT.jar --nogui
```

With Engine Plugins:

```bash
mkdir -p engine-plugins
cp example-engine-plugin/ExampleTickObserver-1.0.0.jar engine-plugins/
java -Xmx2G -jar VioletCore-26.2.local-SNAPSHOT.jar --nogui --engine-plugins-dir engine-plugins
```

First run will create `eula.txt`. Set `eula=true` before running a live server.

## Engine Plugin metadata

Every Engine Plugin jar must include `engine-plugin.yml`:

```yaml
name: ExampleTickObserver
version: 1.0.0
main: dev.violet.example.ExampleTickObserver
type: engine-plugin
target-server: VioletCore
target-version: 26.2
load-phase: pre-minecraft
reloadable: false
modifies:
  - tick-observer-demo
conflicts: []
mixin-configs: []
```

## Source patch locations

The VioletCore implementation is stored as patch files on top of Purpur:

- API additions:
  - `purpur-api/paper-patches/files/src/main/java/io/violetmc/violetcore/engine/api/*.patch`
- Paper/Purpur server additions:
  - `purpur-server/paper-patches/features/0006-VioletCore-engine-plugin-loader.patch`
- Minecraft server hook additions:
  - `purpur-server/minecraft-patches/features/0022-VioletCore-engine-plugin-hooks.patch`
- Branding patch:
  - `purpur-server/build.gradle.kts.patch`

## Build notes

Official Purpur 26.2 requires JDK 25 and Gradle wrapper. In this sandbox, a temporary Temurin JDK 25 was used.

Typical build commands:

```bash
./gradlew applyAllPatches
./gradlew :purpur-server:createBundlerJar -x test
```

The runnable jar is produced under:

```text
purpur-server/build/libs/purpur-bundler-26.2.local-SNAPSHOT.jar
```

For this workspace it was copied to:

```text
/home/user/VioletCore-26.2.local-SNAPSHOT.jar
```
